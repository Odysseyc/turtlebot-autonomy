#!/usr/bin/env python3

import numpy as np
import rclpy

from asl_tb3_lib.control import BaseHeadingController
from asl_tb3_lib.math_utils import wrap_angle
from asl_tb3_msgs.msg import TurtleBotControl, TurtleBotState


class HeadingController(BaseHeadingController):
    def __init__(self) -> None:
        # let the base class set up the node, subscriptions, and control loop
        super().__init__()
        # proportional gain: how hard we turn per radian of heading error
        self.kp = 2.0

    def compute_control_with_goal(self, state: TurtleBotState, goal: TurtleBotState) -> TurtleBotControl:
        # how far off our heading is, wrapped to [-pi, pi] so we always turn the short way
        err = wrap_angle(goal.theta - state.theta)

        # proportional control: turn faster the further off we are
        omega = self.kp * err

        # package the angular velocity into a control message and send it back
        control = TurtleBotControl()
        control.omega = omega
        return control


if __name__ == "__main__":
    # start ROS 2, create our controller node, and keep it running until shut down
    rclpy.init()
    node = HeadingController()
    rclpy.spin(node)
    rclpy.shutdown()
